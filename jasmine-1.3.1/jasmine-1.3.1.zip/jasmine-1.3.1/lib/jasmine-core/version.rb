module Jasmine
  module Core
    VERSION = "1.3.1"
  end
end

